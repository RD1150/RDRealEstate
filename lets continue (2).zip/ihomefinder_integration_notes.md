# iHomeFinder IDX Integration Notes

## Overview
This document provides information about integrating iHomeFinder IDX with the Reena Dutta Real Estate website.

## Subscription Details
- **Plan**: iHomeFinder IDX subscription ($150 plan)
- **Status**: Contracted and ready for integration

## Integration Steps for GoDaddy

### 1. Obtain Integration Code
- Log in to your iHomeFinder account
- Navigate to the "IDX Integration" or similar section
- Copy the provided JavaScript or iframe code for your website

### 2. Create MLS Search Page
- The website already includes a link to "mls-search.html"
- Add the iHomeFinder integration code to this page
- Example placement:

```html
<!-- MLS Search Content -->
<section class="mls-search-section">
    <div class="container">
        <h2>MLS Property Search</h2>
        <p>Use our powerful MLS search tool to find your perfect property.</p>
        
        <!-- Insert iHomeFinder IDX code here -->
        <!-- Example: -->
        <script type="text/javascript" src="https://ihomefinder.com/idx/js/your-account-id"></script>
        <!-- or -->
        <iframe src="https://ihomefinder.com/idx/your-account-id" width="100%" height="800" frameborder="0"></iframe>
    </div>
</section>
```

### 3. Add Property Listings to Area Pages
- You may also want to add specific property listings to area pages
- iHomeFinder typically provides filtered search widgets for specific areas
- These can be added to pages like san-fernando-valley.html, oxnard.html, etc.
- Look for area-specific integration options in your iHomeFinder dashboard

### 4. Mobile Responsiveness
- Ensure the IDX integration is responsive on mobile devices
- Test on various screen sizes after implementation
- iHomeFinder typically provides responsive options in their settings

## Additional Resources
- iHomeFinder support: https://www.ihomefinder.com/support/
- Documentation: https://www.ihomefinder.com/docs/
- Contact your iHomeFinder account representative for specific integration assistance

## Notes for Website Maintenance
- iHomeFinder may periodically update their integration code
- Check for updates in your iHomeFinder account dashboard
- Keep your MLS data feed credentials current
- Regularly test the search functionality to ensure it's working properly
